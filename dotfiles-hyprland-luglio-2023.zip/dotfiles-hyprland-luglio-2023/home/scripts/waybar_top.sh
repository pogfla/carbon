#!/usr/bin/bash
#
# Riccardo Palombo - https://riccardo.im
# Preparato per la community Patreon: patreon.com/riccardopalombo
# 

waybar -c $HOME/.config/waybar/config -s $HOME/.config/waybar/style.css &
